# Portafolio Edu & Lu 🌴

Tracker de inversiones con Firebase + PWA instalable en iPhone.

## Stack
- React + Vite
- Firebase Firestore (base de datos en la nube)
- Recharts (gráficos)
- PWA (instalable en iPhone sin App Store)

---

## Deploy en Vercel (paso a paso)

### Paso 1 — Sube el código a GitHub
1. Ve a github.com → New repository → nombre: `portafolio-edu-lu` → Create
2. Descarga GitHub Desktop (desktop.github.com) si no tienes git
3. Clona el repo vacío y copia estos archivos adentro
4. Commit y Push

### Paso 2 — Conecta con Vercel
1. Ve a vercel.com → Sign up con tu cuenta GitHub
2. "New Project" → importa `portafolio-edu-lu`
3. Framework: Vite (lo detecta automático)
4. Click en **Deploy**
5. En ~2 minutos tienes tu URL: `portafolio-edu-lu.vercel.app`

### Paso 3 — Instala en iPhone
1. Abre la URL en **Safari** (importante: Safari, no Chrome)
2. Toca el ícono de compartir ↑
3. "Añadir a pantalla de inicio"
4. Ya aparece como app en tu iPhone 📱

### Paso 4 — Configura Firestore Rules
En la consola de Firebase → Firestore → Rules, pega esto:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /portfolio/{docId} {
      allow read, write: if true;
    }
  }
}
```

---

## Uso
- **Dashboard**: resumen por tipo de activo y top posiciones
- **Posiciones**: tabla completa, edita cantidad y precio unitario directamente
- **Proyección**: slider de aporte mensual, gráfico y tabla de hitos
- El punto verde "Sincronizado" confirma que los datos están en la nube
- Cualquier cambio se guarda automáticamente en Firebase

## Datos
- Todos los datos se guardan en Firebase Firestore
- Se sincronizan en tiempo real entre todos tus dispositivos
- Si Luciana también abre la misma URL, ve el mismo portafolio
